global.sessionName = "plume-session";
global.owner = ["6285717062467"] // replace your number here.