// HANDLER.js
/**
 * Command Handler for WhatsApp Bot
 * Handles both case and plugin commands
 */
const fs = require("fs");
const path = require("path");
const { smsg } = require("./lib/serialize");
const prefix = global.prefix || '!';

/**
 * Plugin cache to store loaded plugins
 * @type {Map<string, Object>}
 */
const plugins = new Map();

/**
 * Event plugins cache to store event-based plugins
 * @type {Array<Object>}
 */
const eventPlugins = [];

/**
 * Load plugins from directory
 */
function loadPlugins() {
    const pluginsFolder = path.join(__dirname, "playground", "plugins");

    if (!fs.existsSync(path.join(__dirname, "playground"))) {
        fs.mkdirSync(path.join(__dirname, "playground"));
    }

    if (!fs.existsSync(pluginsFolder)) {
        fs.mkdirSync(pluginsFolder, { recursive: true });
    }

    const loadPlugin = (file) => {
        const fileName = path.basename(file);
        const plugin = require(file);

        if (fileName.startsWith("_") && plugin.run && plugin.run.main) {
            eventPlugins.push(plugin.run);
            console.log(`Loaded event plugin: ${fileName}`);
            return;
        }

        if (plugin.run && plugin.run.name) {
            if (plugin.run.alias) {
                if (Array.isArray(plugin.run.alias)) {
                    for (const alias of plugin.run.alias) {
                        if (alias instanceof RegExp) {
                            continue;
                        }
                        plugins.set(alias, plugin.run);
                    }
                }
            }
            plugins.set(plugin.run.name, plugin.run);
            console.log(`Loaded plugin: ${plugin.run.name}`);
        }
    };

    const findPlugins = (dir) => {
        const files = fs.readdirSync(dir, { withFileTypes: true });

        for (const file of files) {
            const filePath = path.join(dir, file.name);

            if (file.isDirectory()) {
                findPlugins(filePath);
            } else if (file.name.endsWith('.js')) {
                try {
                    loadPlugin(filePath);
                } catch (error) {
                    console.error(`Error loading plugin ${filePath}:`, error);
                }
            }
        }
    };

    findPlugins(pluginsFolder);
}

/**
 * Load case commands
 * @returns {Object} The case command object
 */
function loadCase() {
    const caseFile = path.join(__dirname, "playground", "case", "case.js");
    try {
        return require(caseFile);
    } catch (error) {
        console.error("Error loading case file:", error);
        return null;
    }
}

/**
 * Process all event plugins for a message
 * @param {Object} m - Serialized message
 * @param {Object} conn - WhatsApp connection
 * @param {Object} store - Message store
 * @param {Object} chatUpdate - Chat update object
 */
async function processEventPlugins(m, conn, store, chatUpdate) {
    const groupMetadata = m.isGroup ? await conn.groupMetadata(m.chat) : null;
    const participants = m.isGroup ? groupMetadata.participants : [];
    const isAdmin = m.isGroup ? participants.find(p => p.id === m.sender)?.admin : false;
    const isBotAdmin = m.isGroup ? participants.find(p => p.id === conn.user.id)?.admin : false;

    for (const eventPlugin of eventPlugins) {
        try {
            await eventPlugin.main(m, {
                conn,
                isAdmin: isAdmin !== false,
                isBotAdmin: isBotAdmin !== false,
                store,
                chatUpdate
            });
        } catch (error) {
            console.error("Error in event plugin:", error);
        }
    }
}

/**
 * Initialize the handler
 * @param {import("baileys").WASocket} conn 
 * @param {import("baileys").WAMessage} msg 
 * @param {import("baileys").ChatUpdate} chatUpdate
 * @param {store} store 
 */
function initHandler(conn, msg, store, chatUpdate) {
    const m = smsg(conn, msg, store);
    if (!m) return;

    if (m.fromMe) return;

    try {
        processEventPlugins(m, conn, store, chatUpdate);
        if (m.body) {
            if (m.body.startsWith(prefix)) {
                const command = m.body.slice(prefix.length).trim().split(" ")[0].toLowerCase();
                const args = m.body.slice(prefix.length).trim().split(" ").slice(1);
                const text = args.join(" ");

                if (plugins.has(command)) {
                    const plugin = plugins.get(command);
                    const isAdmin = false;
                    const isOwner = false;

                    plugin.exec(m, { conn, text, args, isAdmin, isOwner });
                    return;
                }
                const caseHandler = loadCase();
                if (caseHandler) {
                    caseHandler(m, conn, chatUpdate);
                }
            } else {
                const msgLower = m.body.toLowerCase();
                for (const [key, plugin] of plugins.entries()) {
                    if (plugin.noPrefix === true) {
                        if (plugin.alias) {
                            if (Array.isArray(plugin.alias)) {
                                for (const alias of plugin.alias) {
                                    if (alias instanceof RegExp && alias.test(msgLower)) {
                                        const isAdmin = false;
                                        const isOwner = false;

                                        plugin.exec(m, { conn, text: m.body, args: m.body.split(" "), isAdmin, isOwner });
                                        return;
                                    }
                                }
                            }
                        }
                        if (msgLower === key.toLowerCase()) {
                            const isAdmin = false;
                            const isOwner = false;

                            plugin.exec(m, { conn, text: m.body, args: m.body.split(" "), isAdmin, isOwner });
                            return;
                        }
                    }
                }
            }
        }
    } catch (error) {
        console.error("Error in handler:", error);
    }
}

loadPlugins();

module.exports = initHandler;

// index.js
require("./config")
const { Boom } = require("@hapi/boom");
const { default: makeWASocket, Browsers, useMultiFileAuthState, DisconnectReason, makeInMemoryStore, jidDecode } = require("baileys");
const chalk = require("chalk");
const pino = require("pino");
const readline = require("readline");
const CFont = require("cfonts");
const { startLoading, done, consoleInfo, consoleSuccess, consoleError, doneError } = require("./lib/console");
const handler = require("./handler")

/** @type {boolean} */
const pairingCode = true;
CFont.say("Plume", {
    font: "3d",
    align: "left",
    colors: ["yellowBright", "cyan"]
})


/**
 * Function to ask Phone Number
 * 
 * @param {string} question - Phone number from user, e.g 628xxx
 * @returns {Promise<string>}
 */
function askPhoneNumber(question) {
    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });

    return new Promise((resolve) => {
        const ask = () => {
            rl.question(question, (input) => {
                const cleanedInput = input.replace(/\D/g, '');
                const isValid = /^\d{8,15}$/.test(cleanedInput);
                if (isValid) {
                    rl.close();
                    resolve(cleanedInput);
                } else {
                    console.log('Invalid phone number format. Must contain 8-15 digits, no spaces or symbols.');
                    ask();
                }
            })
        }
        ask();
    });
}

const store = makeInMemoryStore({
    logger: pino().child({ level: "silent", stream: "store" })
})

async function connectToWhatsApp() {
    const { state, saveCreds } = await useMultiFileAuthState(sessionName);
    const conn = makeWASocket({
        logger: pino({ level: "silent" }),
        printQRInTerminal: !pairingCode,
        auth: state,
        browser: Browsers.macOS("Safari")
    });

    if (pairingCode && !conn.authState.creds.registered) {
        const phoneNumber = await askPhoneNumber(chalk.yellowBright("[!] Masukan nomor telepon WhatsApp di awali dengan 628xx: "));
        const code = await conn.requestPairingCode(phoneNumber);
        console.log(chalk.bgGreen(chalk.black("Your Pairing Code")), chalk.green(code.slice(0, 4) + "-" + code.slice(4)))
    }

    conn.ev.on("creds.update", saveCreds);
    conn.ev.on("connection.update", (update) => {
        const { connection, lastDisconnect } = update;
        startLoading("Mendeteksi koneksi...");
        if (connection === "close") {
            const reason = new Boom(lastDisconnect?.error)?.output.statusCode;
            if (reason === DisconnectReason.badSession) {
                doneError("Sesi buruk, Harap hapus folder sesi lalu jalankan ulang script ini.");
                process.exit();
            } else if (reason === DisconnectReason.connectionClosed) {
                consoleInfo("Koneksi tertutup, Mencoba menyambung ulang...");
                connectToWhatsApp();
            } else if (reason === DisconnectReason.connectionLost) {
                consoleInfo("Koneksi tiba-tiba menghilang dari server, Mencoba menyambung ulang...");
                connectToWhatsApp();
            } else if (reason === DisconnectReason.connectionReplaced) {
                doneError("Koneksi Tertimpa, Sesi lainnya sedang terbuka, Mohon untuk merestart script dan coba lagi.");
                process.exit();
            } else if (reason === DisconnectReason.loggedOut) {
                doneError("Sesi telah ter log out, Harap hapus folder sesi dan jalankan lagi script ini.");
                process.exit();
            } else if (reason === DisconnectReason.restartRequired) {
                consoleInfo("Restart di butuhkan, Mencoba merestart...");
                connectToWhatsApp();
            } else if (reason === DisconnectReason.timedOut) {
                consoleInfo("Koneksi time out, Mencoba menyambung ulang...");
                connectToWhatsApp();
            } else {
                consoleError("Koneksi tidak di ketahui...");
                connectToWhatsApp();
            }
        } else if (connection === "open") {
            done("Koneksi berhasil terhubung, Selamat datang Owner!");
        }
    })

    conn.ev.on("messages.upsert", async (chatUpdate) => {
        try {
            if (!chatUpdate.messages) return;
            const msg = chatUpdate.messages[0];
            if (!msg.message) return;
            if (msg.key && msg.key.remoteJid === "status@broadcast") return;
            handler(conn, msg, store);
        } catch (err) {
            console.error(err);
        }
    });

    conn.decodeJid = (jid) => {
        if (!jid) return jid;
        if (/:\d+@/gi.test(jid)) {
            let decode = jidDecode(jid) || {};
            return decode.user && decode.server && decode.user + '@' + decode.server || jid;
        } else return jid;
    };

    conn.sendText = (jid, text, quoted = '', options = {}) => {
        return conn.sendMessage(jid, { text: text, ...options }, { quoted, ...options });
    };

    return conn;
}

connectToWhatsApp();